package com.example.demo.Repositortyy;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.Duser;

public interface DRepository extends JpaRepository<Duser ,Long> {

}
