package com.example.demo.Model;

public enum Role {
	PATIENT , DOCTOR

}
